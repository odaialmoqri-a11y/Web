# LAN Guardian - نظام مراقبة الشبكة

نظام خفيف ومرني لمراقبة الشبكات في الوقت الحقيقي لاكتشاف الأجهزة غير المصرح بها.

## المميزات

- فحص الشبكة المحلية باستخدام Scapy
- اكتشاف جميع الأجهزة المتصلة تلقائياً
- تحديد الأجهزة غير المصرح بها
- تحليل سلوكي بسيط قائم على القواعد
- تنبيهات فورية
- لوحة تحكم حديثة
- تقارير PDF
- نظام مصادقة آمن

## المتطلبات

- Python 3.11+
- Node.js 18+
- MySQL 8.0+
- صلاحيات Root (لفحص الشبكة)

## التثبيت

### 1. استنساخ المشروع

```bash
git clone <repository-url>
cd lan-guardian
```

### 2. الواجهة الخلفية (Backend)

```bash
cd backend

# إنشاء بيئة افتراضية
python -m venv venv
source venv/bin/activate  # Linux/Mac
# أو
venv\Scripts\activate  # Windows

# تثبيت المتطلبات
pip install -r requirements.txt

# نسخ ملف الإعدادات
cp .env.example .env
# ثم قم بتعديل ملف .env according to your settings

# تشغيل الخادم
uvicorn app.main:app --reload
```

### 3. الواجهة الأمامية (Frontend)

```bash
cd frontend

# تثبيت المتطلبات
npm install

# تشغيل التطبيق
npm start
```

### 4. باستخدام Docker

```bash
docker-compose up -d
```

## الاستخدام

### بيانات تسجيل الدخول الافتراضية

- اسم المستخدم: `admin`
- كلمة المرور: `admin123`

### واجهة البرمجة

- الواجهة الخلفية: http://localhost:8000
- التوثيق: http://localhost:8000/docs
- الواجهة الأمامية: http://localhost:3000

## هيكل المشروع

```
lan-guardian/
├── backend/                 # الواجهة الخلفية
│   ├── app/
│   │   ├── api/            # نقاط النهاية
│   │   ├── core/           # الإعدادات والأمان
│   │   ├── db/             # قاعدة البيانات
│   │   ├── schemas/        # نماذج Pydantic
│   │   └── services/       # الخدمات
│   ├── requirements.txt
│   └── .env
├── frontend/               # الواجهة الأمامية
│   ├── src/
│   │   ├── components/    # المكونات
│   │   ├── pages/         # الصفحات
│   │   ├── context/       # السياق
│   │   └── services/      # الخدمات
│   └── package.json
└── docker-compose.yml      # Docker
```

## المسارات API

### المصادقة
- `POST /api/v1/auth/login` - تسجيل الدخول
- `GET /api/v1/auth/me` - المستخدم الحالي

### الأجهزة
- `GET /api/v1/devices` - قائمة الأجهزة
- `PUT /api/v1/devices/{id}/authorize` - الموافقة على جهاز

### لوحة التحكم
- `GET /api/v1/dashboard/stats` - الإحصائيات
- `POST /api/v1/dashboard/scan` - تشغيل فحص

### التقارير
- `GET /api/v1/reports/security` - تقرير أمني
- `GET /api/v1/reports/devices` - تقرير الأجهزة

## الملاحظات

- يتطلب فحص الشبكة صلاحيات Root
- تأكد من أن端口 8000 و 3000 متاحة
- في بيئة الإنتاج، قم بتغيير SECRET_KEY

## الترخيص

MIT License
