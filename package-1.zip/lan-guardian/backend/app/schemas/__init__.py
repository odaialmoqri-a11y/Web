"""
مخططات التحقق من صحة البيانات
تعريف نماذج Pydantic لواجهة API
"""

from pydantic import BaseModel, EmailStr, Field
from typing import Optional
from datetime import datetime


# ===== مخططات المستخدم =====

class UserBase(BaseModel):
    """أساس بيانات المستخدم"""
    username: str = Field(..., min_length=3, max_length=50)
    email: Optional[EmailStr] = None
    role: str = "viewer"


class UserCreate(UserBase):
    """إنشاء مستخدم جديد"""
    password: str = Field(..., min_length=6)


class UserUpdate(BaseModel):
    """تحديث بيانات المستخدم"""
    email: Optional[EmailStr] = None
    password: Optional[str] = None
    role: Optional[str] = None
    is_active: Optional[bool] = None


class UserResponse(UserBase):
    """استجابة بيانات المستخدم"""
    id: int
    is_active: bool
    created_at: datetime

    class Config:
        from_attributes = True


class UserLogin(BaseModel):
    """تسجيل الدخول"""
    username: str
    password: str


class Token(BaseModel):
    """Token الوصول"""
    access_token: str
    token_type: str = "bearer"


class TokenData(BaseModel):
    """بيانات Token"""
    username: Optional[str] = None


# ===== مخططات الأجهزة =====

class DeviceBase(BaseModel):
    """أساس بيانات الجهاز"""
    mac_address: str
    ip_address: Optional[str] = None
    hostname: Optional[str] = None
    vendor: Optional[str] = None
    device_type: Optional[str] = None


class DeviceCreate(DeviceBase):
    """إضافة جهاز جديد"""
    is_authorized: bool = False


class DeviceUpdate(BaseModel):
    """تحديث بيانات الجهاز"""
    ip_address: Optional[str] = None
    hostname: Optional[str] = None
    vendor: Optional[str] = None
    device_type: Optional[str] = None
    is_authorized: Optional[bool] = None
    notes: Optional[str] = None


class DeviceResponse(DeviceBase):
    """استجابة بيانات الجهاز"""
    id: int
    is_authorized: bool
    is_online: bool
    first_seen: datetime
    last_seen: datetime
    authorized_at: Optional[datetime]
    notes: Optional[str]

    class Config:
        from_attributes = True


class DeviceStats(BaseModel):
    """إحصائيات الأجهزة"""
    total_devices: int
    online_devices: int
    unauthorized_devices: int
    new_today: int
    by_type: dict


# ===== مخططات التنبيهات =====

class AlertBase(BaseModel):
    """أساس بيانات التنبيه"""
    alert_type: str
    message: str
    severity: str = "medium"


class AlertResponse(AlertBase):
    """استجابة بيانات التنبيه"""
    id: int
    device_id: Optional[int]
    is_read: bool
    created_at: datetime

    class Config:
        from_attributes = True


class AlertCreate(AlertBase):
    """إنشاء تنبيه"""
    device_id: Optional[int] = None


class AlertUpdate(BaseModel):
    """تحديث التنبيه"""
    is_read: Optional[bool] = None


# ===== مخططات سجلات الفحص =====

class ScanLogBase(BaseModel):
    """أساس سجل الفحص"""
    scan_type: str = "arp"
    devices_found: int = 0
    new_devices: int = 0
    unauthorized_devices: int = 0
    status: str = "completed"


class ScanLogResponse(ScanLogBase):
    """استجابة سجل الفحص"""
    id: int
    duration: Optional[int]
    created_at: datetime

    class Config:
        from_attributes = True


# ===== مخططات لوحة التحكم =====

class DashboardStats(BaseModel):
    """إحصائيات لوحة التحكم"""
    total_devices: int
    online_devices: int
    unauthorized_devices: int
    new_today: int
    total_alerts: int
    unread_alerts: int
    last_scan: Optional[datetime]


class NetworkActivity(BaseModel):
    """نشاط الشبكة"""
    timestamp: datetime
    devices_online: int
    new_devices: int
    alerts_count: int


# ===== مخططات التقارير =====

class ReportRequest(BaseModel):
    """طلب تقرير"""
    report_type: str = "security"  # security, devices, alerts
    start_date: Optional[datetime] = None
    end_date: Optional[datetime] = None
    device_id: Optional[int] = None


class ReportResponse(BaseModel):
    """استجابة التقرير"""
    filename: str
    content: bytes
    content_type: str = "application/pdf"
