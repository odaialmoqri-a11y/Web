"""
تطبيق FastAPI الرئيسي
نقطة الدخول لنظام LAN Guardian
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from app.core.config import settings
from app.db.session import engine, Base
from app.api.v1 import auth, devices, dashboard, reports


@asynccontextmanager
async def lifespan(app: FastAPI):
    """إدارة دورة حياة التطبيق"""
    # إنشاء الجداول
    Base.metadata.create_all(bind=engine)

    # إنشاء مستخدم admin افتراضي
    from app.db.session import SessionLocal
    from app.db.models import User
    from app.core.security import get_password_hash

    db = SessionLocal()
    try:
        admin = db.query(User).filter(User.username == "admin").first()
        if not admin:
            admin = User(
                username="admin",
                email="admin@lan-guardian.local",
                password_hash=get_password_hash("admin123"),
                role="admin",
                is_active=True
            )
            db.add(admin)
            db.commit()
            print("تم إنشاء مستخدم admin الافتراضي")
    finally:
        db.close()

    # بدء الفحص المستمر
    from app.services.scanner_engine import scanner
    scanner.start_continuous_scan()

    yield

    # إيقاف الفحص عند关闭
    scanner.stop_scan()


# إنشاء تطبيق FastAPI
app = FastAPI(
    title="LAN Guardian API",
    description="نظام مراقبة الشبكة - واجهة برمجة التطبيقات",
    version="1.0.0",
    lifespan=lifespan
)

# إعداد CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # في الإنتاج، يجب تحديد النطاقات المسموحة
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# تسجيل المسارات
app.include_router(auth.router, prefix="/api/v1")
app.include_router(devices.router, prefix="/api/v1")
app.include_router(dashboard.router, prefix="/api/v1")
app.include_router(reports.router, prefix="/api/v1")


@app.get("/")
def root():
    """الصفحة الرئيسية"""
    return {
        "name": "LAN Guardian API",
        "version": "1.0.0",
        "description": "نظام مراقبة الشبكة المحلية",
        "docs": "/docs",
        "redoc": "/redoc"
    }


@app.get("/health")
def health_check():
    """فحص حالة النظام"""
    return {
        "status": "healthy",
        "service": "LAN Guardian API"
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host=settings.SERVER_HOST,
        port=settings.SERVER_PORT,
        reload=settings.DEBUG
    )
