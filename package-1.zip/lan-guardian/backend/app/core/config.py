"""
وحدة الإعدادات الأساسية للنظام
تحميل المتغيرات من ملف .env وإعدادات التطبيق
"""

from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    """إعدادات التطبيق الرئيسية"""

    # إعدادات قاعدة البيانات
    DB_HOST: str = "localhost"
    DB_PORT: int = 3306
    DB_NAME: str = "lan_guardian"
    DB_USER: str = "root"
    DB_PASSWORD: str = "password"

    # إعدادات JWT
    SECRET_KEY: str = "your-secret-key-change-in-production"
    ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 30

    # إعدادات الخادم
    SERVER_HOST: str = "0.0.0.0"
    SERVER_PORT: int = 8000
    DEBUG: bool = True

    # إعدادات الفحص
    SCAN_INTERVAL: int = 30
    NETWORK_INTERFACE: str = "eth0"
    SUBNET: str = "192.168.1.0/24"

    @property
    def DATABASE_URL(self) -> str:
        """إنشاء رابط قاعدة البيانات"""
        return f"mysql+pymysql://{self.DB_USER}:{self.DB_PASSWORD}@{self.DB_HOST}:{self.DB_PORT}/{self.DB_NAME}"

    class Config:
        env_file = ".env"
        case_sensitive = True


# إنشاء كائن الإعدادات العامة
settings = Settings()
