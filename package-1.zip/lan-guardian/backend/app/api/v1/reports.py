"""
واجهة برمجة التطبيقات - التقارير
إنشاء وتصدير التقارير
"""

from datetime import datetime, timedelta
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, status, Query
from fastapi.responses import StreamingResponse
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.db.models import User
from app.core.security import get_current_user
from app.schemas import ReportRequest
from app.services.pdf_generator import pdf_generator

router = APIRouter(prefix="/reports", tags=["التقارير"])


@router.get("/security")
def generate_security_report(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """إنشاء وتصدير تقرير أمني"""

    # تحويل التواريخ
    start = None
    end = None

    if start_date:
        try:
            start = datetime.fromisoformat(start_date)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="صيغة تاريخ البداية غير صحيحة"
            )

    if end_date:
        try:
            end = datetime.fromisoformat(end_date)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="صيغة تاريخ النهاية غير صحيحة"
            )

    # إنشاء التقرير
    try:
        pdf_content = pdf_generator.generate_security_report(
            start_date=start,
            end_date=end
        )
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"خطأ في إنشاء التقرير: {str(e)}"
        )

    # إرسال الملف
    filename = f"security_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"

    return StreamingResponse(
        iter([pdf_content]),
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename={filename}"
        }
    )


@router.get("/devices")
def generate_devices_report(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """إنشاء وتصدير تقرير الأجهزة"""

    try:
        pdf_content = pdf_generator.generate_devices_report()
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"خطأ في إنشاء التقرير: {str(e)}"
        )

    filename = f"devices_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"

    return StreamingResponse(
        iter([pdf_content]),
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename={filename}"
        }
    )


@router.get("/alerts")
def generate_alerts_report(
    start_date: Optional[str] = None,
    end_date: Optional[str] = None,
    severity: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """إنشاء وتصدير تقرير التنبيهات"""

    from app.db.models import Alert
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Table, TableStyle, Spacer
    from reportlab.lib.styles import getSampleStyleSheet
    from reportlab.lib.units import inch
    import io

    # تحويل التواريخ
    start = None
    end = None

    if start_date:
        try:
            start = datetime.fromisoformat(start_date)
        except ValueError:
            start = datetime.now() - timedelta(days=7)

    if end_date:
        try:
            end = datetime.fromisoformat(end_date)
        except ValueError:
            end = datetime.now()

    # الحصول على التنبيهات
    query = db.query(Alert)

    if start:
        query = query.filter(Alert.created_at >= start)
    if end:
        query = query.filter(Alert.created_at <= end)
    if severity:
        query = query.filter(Alert.severity == severity)

    alerts = query.order_by(Alert.created_at.desc()).all()

    # إنشاء PDF
    buffer = io.BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=A4, rightMargin=72, leftMargin=72, topMargin=72, bottomMargin=72)

    styles = getSampleStyleSheet()
    story = []

    # العنوان
    story.append(Paragraph("تقرير التنبيهات", styles['Title']))
    story.append(Paragraph(f"الفترة: {start.strftime('%Y-%m-%d') if start else 'الكل'} إلى {end.strftime('%Y-%m-%d') if end else 'الكل'}", styles['Normal']))
    story.append(Spacer(1, 20))

    # الجدول
    if alerts:
        data = [['التاريخ', 'النوع', 'الرسالة', 'الخطورة', 'الحالة']]
        for alert in alerts:
            data.append([
                alert.created_at.strftime('%Y-%m-%d %H:%M'),
                alert.alert_type,
                alert.message[:40] + '...' if len(alert.message) > 40 else alert.message,
                alert.severity,
                'مقروء' if alert.is_read else 'غير مقروء'
            ])

        table = Table(data, colWidths=[1.3*inch, 0.9*inch, 2.5*inch, 0.7*inch, 0.7*inch])
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0d6efd')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'RIGHT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f9fa')])
        ]))
        story.append(table)
    else:
        story.append(Paragraph("لا توجد تنبيهات في الفترة المحددة", styles['Normal']))

    doc.build(story)
    buffer.seek(0)

    filename = f"alerts_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"

    return StreamingResponse(
        iter([buffer.getvalue()]),
        media_type="application/pdf",
        headers={
            "Content-Disposition": f"attachment; filename={filename}"
        }
    )


@router.get("/summary")
def get_report_summary(
    days: int = 7,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """الحصول على ملخص للتقارير"""

    from app.db.models import Device, Alert, ScanLog

    start_date = datetime.now() - timedelta(days=days)

    # الأجهزة
    total = db.query(Device).count()
    authorized = db.query(Device).filter(Device.is_authorized == True).count()
    unauthorized = db.query(Device).filter(Device.is_authorized == False).count()

    # التنبيهات
    total_alerts = db.query(Alert).filter(Alert.created_at >= start_date).count()
    critical = db.query(Alert).filter(
        Alert.created_at >= start_date,
        Alert.severity == 'critical'
    ).count()
    high = db.query(Alert).filter(
        Alert.created_at >= start_date,
        Alert.severity == 'high'
    ).count()

    # الفحوصات
    scans = db.query(ScanLog).filter(ScanLog.created_at >= start_date).count()

    return {
        "period_days": days,
        "devices": {
            "total": total,
            "authorized": authorized,
            "unauthorized": unauthorized
        },
        "alerts": {
            "total": total_alerts,
            "critical": critical,
            "high": high
        },
        "scans": scans
    }
