"""
واجهة برمجة التطبيقات - لوحة التحكم
إحصائيات لوحة التحكم والنشاط
"""

from typing import List
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.db.models import Device, Alert, ScanLog, User
from app.core.security import get_current_user
from app.schemas import DashboardStats, NetworkActivity, ScanLogResponse

router = APIRouter(prefix="/dashboard", tags=["لوحة التحكم"])


@router.get("/stats", response_model=DashboardStats)
def get_dashboard_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """الحصول على إحصائيات لوحة التحكم"""

    # إحصائيات الأجهزة
    total_devices = db.query(Device).count()
    online_devices = db.query(Device).filter(Device.is_online == True).count()
    unauthorized_devices = db.query(Device).filter(Device.is_authorized == False).count()

    # الأجهزة الجديدة اليوم
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    new_today = db.query(Device).filter(Device.first_seen >= today).count()

    # إحصائيات التنبيهات
    total_alerts = db.query(Alert).count()
    unread_alerts = db.query(Alert).filter(Alert.is_read == False).count()

    # آخر فحص
    last_scan = db.query(ScanLog).filter(
        ScanLog.status == "completed"
    ).order_by(ScanLog.created_at.desc()).first()

    return {
        "total_devices": total_devices,
        "online_devices": online_devices,
        "unauthorized_devices": unauthorized_devices,
        "new_today": new_today,
        "total_alerts": total_alerts,
        "unread_alerts": unread_alerts,
        "last_scan": last_scan.created_at if last_scan else None
    }


@router.get("/activity", response_model=List[NetworkActivity])
def get_network_activity(
    hours: int = 24,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """الحصول على نشاط الشبكة"""

    start_time = datetime.now() - timedelta(hours=hours)

    # الحصول على سجلات الفحص
    scans = db.query(ScanLog).filter(
        ScanLog.created_at >= start_time,
        ScanLog.status == "completed"
    ).order_by(ScanLog.created_at.asc()).all()

    activities = []
    for scan in scans:
        # حساب عدد الأجهزة الجديدة في هذا الفحص
        new_devices = db.query(Device).filter(
            Device.first_seen >= scan.created_at - timedelta(minutes=1),
            Device.first_seen <= scan.created_at + timedelta(minutes=1)
        ).count()

        # عدد التنبيهات في هذا الوقت
        alerts_count = db.query(Alert).filter(
            Alert.created_at >= scan.created_at - timedelta(minutes=1),
            Alert.created_at <= scan.created_at + timedelta(minutes=1)
        ).count()

        activities.append({
            "timestamp": scan.created_at,
            "devices_online": scan.devices_found,
            "new_devices": new_devices,
            "alerts_count": alerts_count
        })

    return activities


@router.get("/recent-alerts", response_model=List[dict])
def get_recent_alerts(
    limit: int = 10,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """الحصول على أحدث التنبيهات"""

    alerts = db.query(Alert).order_by(Alert.created_at.desc()).limit(limit).all()

    result = []
    for alert in alerts:
        device = db.query(Device).filter(Device.id == alert.device_id).first() if alert.device_id else None

        result.append({
            "id": alert.id,
            "alert_type": alert.alert_type,
            "message": alert.message,
            "severity": alert.severity,
            "is_read": alert.is_read,
            "created_at": alert.created_at,
            "device": {
                "id": device.id,
                "mac_address": device.mac_address,
                "ip_address": device.ip_address,
                "hostname": device.hostname
            } if device else None
        })

    return result


@router.get("/scan-history", response_model=List[ScanLogResponse])
def get_scan_history(
    skip: int = 0,
    limit: int = 20,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """الحصول على سجل عمليات الفحص"""

    scans = db.query(ScanLog).order_by(
        ScanLog.created_at.desc()
    ).offset(skip).limit(limit).all()

    return scans


@router.post("/scan", status_code=200)
def trigger_scan(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """تشغيل فحص الشبكة يدوياً"""

    from app.services.scanner_engine import scanner

    # التحقق من عدم وجود فحص قيد التنفيذ
    if scanner.is_scanning:
        return {"message": "الفحص قيد التنفيذ بالفعل", "status": "running"}

    # تشغيل الفحص في الخلفية
    import threading
    scan_thread = threading.Thread(target=scanner.run_scan, daemon=True)
    scan_thread.start()

    return {"message": "تم بدء الفحص", "status": "started"}


@router.get("/scan-status")
def get_scan_status(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """الحصول على حالة الفحص الحالي"""

    from app.services.scanner_engine import scanner

    # آخر فحص
    last_scan = db.query(ScanLog).filter(
        ScanLog.status == "completed"
    ).order_by(ScanLog.created_at.desc()).first()

    return {
        "is_scanning": scanner.is_scanning,
        "last_scan": {
            "id": last_scan.id,
            "devices_found": last_scan.devices_found,
            "new_devices": last_scan.new_devices,
            "unauthorized_devices": last_scan.unauthorized_devices,
            "duration": last_scan.duration,
            "created_at": last_scan.created_at
        } if last_scan else None
    }
