"""
واجهة برمجة التطبيقات - الأجهزة
إدارة الأجهزة المصرح بها وغير المصرح بها
"""

from typing import List, Optional
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.orm import Session

from app.db.session import get_db
from app.db.models import Device, Alert, AuditLog, User
from app.core.security import get_current_user, get_current_admin
from app.schemas import (
    DeviceCreate, DeviceUpdate, DeviceResponse,
    DeviceStats, AlertCreate, AlertResponse, AlertUpdate
)

router = APIRouter(prefix="/devices", tags=["الأجهزة"])


# ===== نقاط نهاية الأجهزة =====

@router.get("", response_model=List[DeviceResponse])
def get_devices(
    skip: int = 0,
    limit: int = 100,
    authorized: Optional[bool] = None,
    online: Optional[bool] = None,
    search: Optional[str] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """الحصول على قائمة الأجهزة"""
    query = db.query(Device)

    # تطبيق الفلاتر
    if authorized is not None:
        query = query.filter(Device.is_authorized == authorized)
    if online is not None:
        query = query.filter(Device.is_online == online)
    if search:
        query = query.filter(
            (Device.mac_address.contains(search)) |
            (Device.ip_address.contains(search)) |
            (Device.hostname.contains(search)) |
            (Device.vendor.contains(search))
        )

    devices = query.order_by(Device.last_seen.desc()).offset(skip).limit(limit).all()
    return devices


@router.get("/stats", response_model=DeviceStats)
def get_device_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """الحصول على إحصائيات الأجهزة"""
    total_devices = db.query(Device).count()
    online_devices = db.query(Device).filter(Device.is_online == True).count()
    unauthorized_devices = db.query(Device).filter(Device.is_authorized == False).count()

    # الأجهزة الجديدة اليوم
    today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
    new_today = db.query(Device).filter(Device.first_seen >= today).count()

    # الإحصائيات حسب النوع
    by_type = {}
    devices = db.query(Device).all()
    for device in devices:
        device_type = device.device_type or "Unknown"
        by_type[device_type] = by_type.get(device_type, 0) + 1

    return {
        "total_devices": total_devices,
        "online_devices": online_devices,
        "unauthorized_devices": unauthorized_devices,
        "new_today": new_today,
        "by_type": by_type
    }


@router.get("/{device_id}", response_model=DeviceResponse)
def get_device(
    device_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """الحصول على جهاز معين"""
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="الجهاز غير موجود"
        )
    return device


@router.post("", response_model=DeviceResponse)
def create_device(
    device: DeviceCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin)
):
    """إضافة جهاز جديد"""
    # التحقق من وجود الجهاز
    existing = db.query(Device).filter(Device.mac_address == device.mac_address).first()
    if existing:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="الجهاز موجود بالفعل"
        )

    # إنشاء الجهاز
    db_device = Device(
        mac_address=device.mac_address,
        ip_address=device.ip_address,
        hostname=device.hostname,
        vendor=device.vendor,
        device_type=device.device_type,
        is_authorized=device.is_authorized
    )

    db.add(db_device)
    db.commit()
    db.refresh(db_device)

    # تسجيل العملية
    audit = AuditLog(
        user_id=current_user.id,
        action="create_device",
        entity_type="device",
        entity_id=db_device.id,
        details=f"تم إضافة جهاز: {device.mac_address}"
    )
    db.add(audit)
    db.commit()

    return db_device


@router.put("/{device_id}", response_model=DeviceResponse)
def update_device(
    device_id: int,
    device_update: DeviceUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """تحديث بيانات الجهاز"""
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="الجهاز غير موجود"
        )

    # تحديث الحقول
    update_data = device_update.dict(exclude_unset=True)
    for field, value in update_data.items():
        setattr(device, field, value)

    db.commit()
    db.refresh(device)

    # تسجيل العملية
    audit = AuditLog(
        user_id=current_user.id,
        action="update_device",
        entity_type="device",
        entity_id=device.id,
        details=f"تم تحديث جهاز: {device.mac_address}"
    )
    db.add(audit)
    db.commit()

    return device


@router.put("/{device_id}/authorize", response_model=DeviceResponse)
def authorize_device(
    device_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin)
):
    """الموافقة على جهاز"""
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="الجهاز غير موجود"
        )

    device.is_authorized = True
    device.authorized_at = datetime.now()

    db.commit()
    db.refresh(device)

    # إنشاء تنبيه
    alert = Alert(
        device_id=device.id,
        user_id=current_user.id,
        alert_type="authorized",
        message=f"تم الموافقة على الجهاز: {device.mac_address}",
        severity="low"
    )
    db.add(alert)

    # تسجيل العملية
    audit = AuditLog(
        user_id=current_user.id,
        action="authorize_device",
        entity_type="device",
        entity_id=device.id,
        details=f"تم الموافقة على جهاز: {device.mac_address}"
    )
    db.add(audit)
    db.commit()

    return device


@router.delete("/{device_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_device(
    device_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_admin)
):
    """حذف جهاز"""
    device = db.query(Device).filter(Device.id == device_id).first()
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="الجهاز غير موجود"
        )

    mac_address = device.mac_address

    # حذف التنبيهات المرتبطة
    db.query(Alert).filter(Alert.device_id == device_id).delete()

    # حذف الجهاز
    db.delete(device)
    db.commit()

    # تسجيل العملية
    audit = AuditLog(
        user_id=current_user.id,
        action="delete_device",
        entity_type="device",
        entity_id=device_id,
        details=f"تم حذف جهاز: {mac_address}"
    )
    db.add(audit)
    db.commit()

    return None


# ===== نقاط نهاية التنبيهات =====

@router.get("/alerts", response_model=List[AlertResponse])
def get_alerts(
    skip: int = 0,
    limit: int = 50,
    unread_only: bool = False,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """الحصول على قائمة التنبيهات"""
    query = db.query(Alert)

    if unread_only:
        query = query.filter(Alert.is_read == False)

    alerts = query.order_by(Alert.created_at.desc()).offset(skip).limit(limit).all()
    return alerts


@router.put("/alerts/{alert_id}/read", response_model=AlertResponse)
def mark_alert_read(
    alert_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """وضع علامة مقروء على التنبيه"""
    alert = db.query(Alert).filter(Alert.id == alert_id).first()
    if not alert:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="التنبيه غير موجود"
        )

    alert.is_read = True
    db.commit()
    db.refresh(alert)

    return alert


@router.put("/alerts/read-all", status_code=status.HTTP_200_OK)
def mark_all_alerts_read(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """وضع علامة مقروء على جميع التنبيهات"""
    db.query(Alert).filter(Alert.is_read == False).update({'is_read': True})
    db.commit()

    return {"message": "تم وضع علامة مقروء على جميع التنبيهات"}
