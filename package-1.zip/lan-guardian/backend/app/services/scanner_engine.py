"""
محرك فحص الشبكة
فحص الشبكة المحلية باستخدام Scapy لاكتشاف الأجهزة
"""

import logging
import threading
import time
from datetime import datetime
from typing import List, Dict, Optional
import subprocess

from sqlalchemy.orm import Session

from app.db.session import SessionLocal
from app.db.models import Device, Alert, ScanLog
from app.core.config import settings

# إعداد السجل
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class NetworkScanner:
    """محرك فحص الشبكة"""

    def __init__(self):
        self.is_scanning = False
        self.scan_thread = None
        self.db: Optional[Session] = None
        self.oui_database = self._load_oui_database()

    def _load_oui_database(self) -> Dict[str, str]:
        """تحميل قاعدة بيانات OUI للمصنعين"""
        oui_db = {}
        try:
            # محاولة تحميل ملف OUI
            with open('/workspace/lan-guardian/backend/app/services/oui.txt', 'r') as f:
                for line in f:
                    if line.strip() and '(' in line:
                        parts = line.split(')')
                        if len(parts) >= 2:
                            mac_prefix = parts[0].replace('(', '').replace(')', '').replace('-', ':').upper()
                            vendor = parts[1].strip()
                            oui_db[mac_prefix] = vendor
        except FileNotFoundError:
            logger.warning("ملف OUI غير موجود، سيتم استخدام مصنعين أساسيين")
            # مصنعين أساسيين常见的制造商前缀
            oui_db = {
                '00:50:56': 'VMware',
                '00:0C:29': 'VMware',
                'B8:27:EB': 'Raspberry Pi',
                'DC:A6:32': 'Raspberry Pi',
                '00:1A:2B': 'Cisco',
                '00:1E:68': 'Cisco',
                'F4:CF:E2': 'Cisco',
                '00:50:B6': 'Linksys',
                'C0:C1:C0': 'D-Link',
                '00:24:01': 'NETGEAR',
                'C4:04:15': 'NETGEAR',
                '00:1F:33': 'NETGEAR',
                '20:CF:30': 'ASUSTek',
                'AC:9E:17': 'ASUSTek',
                'F0:79:59': 'Apple',
                '3C:06:30': 'Apple',
                'A4:83:E7': 'Apple',
                '00:1C:B3': 'Apple',
                'F4:F5:D8': 'Samsung',
                '8C:F5:A3': 'Samsung',
                '00:1D:F6': 'Samsung',
                '00:1A:8A': 'Samsung',
                '00:1E:E3': 'Samsung',
                '00:24:54': 'Dell',
                '18:66:DA': 'Dell',
                '18:A9:9B': 'Dell',
                '18:03:73': 'Dell',
                '00:1A:A0': 'Dell',
                '00:25:64': 'Dell',
                '3C:97:0E': 'Wistron',
                '48:4D:7E': 'HP',
                '00:17:A4': 'HP',
                '00:21:5A': 'HP',
                '00:1B:78': 'HP',
                '00:26:B9': 'HP',
                '00:50:B6': 'Linksys',
                'C4:6E:1F': 'LG',
                '10:F1:F2': 'Microsoft',
                '28:18:78': 'Microsoft',
                '00:03:FF': 'Microsoft',
                '30:59:B7': 'Google',
                'F4:F5:D8': 'Google',
                '00:1C:2E': 'HUAWEI',
                '00:25:68': 'HUAWEI',
                '00:34FE': 'HUAWEI',
                'E4:5F:01': 'Raspberry Pi',
            }
        return oui_db

    def get_vendor(self, mac_address: str) -> str:
        """الحصول على اسم المصنع من عنوان MAC"""
        if not mac_address:
            return "Unknown"

        mac_prefix = mac_address.upper().replace('-', ':').split(':')[:3]
        mac_prefix_str = ':'.join(mac_prefix)

        # البحث في قاعدة البيانات
        for prefix, vendor in self.oui_database.items():
            if mac_prefix_str.startswith(prefix.replace('-', ':')):
                return vendor

        return "Unknown"

    def get_hostname(self, ip: str) -> Optional[str]:
        """الحصول على اسم المضيف من IP"""
        try:
            result = subprocess.run(
                ['nmblookup', '-A', ip],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if '<00>' in line and 'GROUP' not in line:
                        return line.split()[0]
        except Exception:
            pass

        try:
            result = subprocess.run(
                ['nslookup', ip],
                capture_output=True,
                text=True,
                timeout=5
            )
            if result.returncode == 0:
                for line in result.stdout.split('\n'):
                    if 'name' in line.lower():
                        hostname = line.split('=')[-1].strip().rstrip('.')
                        if hostname and hostname != ip:
                            return hostname
        except Exception:
            pass

        return None

    def scan_network(self) -> List[Dict]:
        """فحص الشبكة بالكامل"""
        devices = []

        try:
            # استخدام Scapy لفحص الشبكة
            from scapy.all import ARP, Ether, srp

            logger.info(f"بدء فحص الشبكة: {settings.SUBNET}")

            # إنشاء حزمة ARP
            arp = ARP(pdst=settings.SUBNET)
            ether = Ether(dst="ff:ff:ff:ff:ff:ff")
            packet = ether / arp

            # إرسال الحزمة واستقبال الاستجابات
            result = srp(packet, timeout=3, verbose=False, iface=settings.NETWORK_INTERFACE)[0]

            # تحليل النتائج
            for sent, received in result:
                device_info = {
                    'ip': received.psrc,
                    'mac': received.hwsrc.upper(),
                    'vendor': self.get_vendor(received.hwsrc),
                    'hostname': self.get_hostname(received.psrc)
                }
                devices.append(device_info)
                logger.info(f"تم اكتشاف جهاز: {device_info}")

        except ImportError:
            logger.warning("Scapy غير مثبت، استخدام طريقة بديلة")
            devices = self._scan_alternative()
        except Exception as e:
            logger.error(f"خطأ في الفحص: {e}")
            devices = self._scan_alternative()

        return devices

    def _scan_alternative(self) -> List[Dict]:
        """طريقة بديلة للفحص باستخدام ping"""
        devices = []
        subnet = settings.SUBNET.replace('/24', '')

        try:
            # فحص جميع عناوين IP
            for i in range(1, 255):
                ip = f"{subnet}.{i}"
                try:
                    result = subprocess.run(
                        ['ping', '-c', '1', '-W', '1', ip],
                        capture_output=True,
                        timeout=2
                    )
                    if result.returncode == 0:
                        # الحصول على MAC من ARP
                        arp_result = subprocess.run(
                            ['arp', '-n', ip],
                            capture_output=True,
                            text=True
                        )
                        mac = "Unknown"
                        for line in arp_result.stdout.split('\n'):
                            if ':' in line and 'Address' not in line:
                                parts = line.split()
                                if len(parts) >= 3:
                                    mac = parts[2].upper()

                        device_info = {
                            'ip': ip,
                            'mac': mac,
                            'vendor': self.get_vendor(mac),
                            'hostname': None
                        }
                        devices.append(device_info)
                except Exception:
                    continue
        except Exception as e:
            logger.error(f"خطأ في الفحص البديل: {e}")

        return devices

    def process_scan_results(self, devices: List[Dict]) -> Dict:
        """معالجة نتائج الفحص ومقارنتها مع قاعدة البيانات"""
        if not self.db:
            self.db = SessionLocal()

        new_devices = 0
        unauthorized_devices = 0

        for device_data in devices:
            mac = device_data['mac']
            ip = device_data['ip']

            # البحث عن الجهاز في قاعدة البيانات
            device = self.db.query(Device).filter(Device.mac_address == mac).first()

            if device:
                # تحديث معلومات الجهاز
                device.ip_address = ip
                device.last_seen = datetime.now()
                device.is_online = True

                if device.hostname is None and device_data.get('hostname'):
                    device.hostname = device_data['hostname']

            else:
                # جهاز جديد
                new_devices += 1
                device = Device(
                    mac_address=mac,
                    ip_address=ip,
                    hostname=device_data.get('hostname'),
                    vendor=device_data.get('vendor', 'Unknown'),
                    is_authorized=False,
                    is_online=True
                )
                self.db.add(device)
                self.db.flush()

                # إنشاء تنبيه لجهاز جديد غير مصرح به
                unauthorized_devices += 1
                alert = Alert(
                    device_id=device.id,
                    alert_type="unauthorized",
                    message=f"تم اكتشاف جهاز جديد غير مصرح به: {mac}",
                    severity="high"
                )
                self.db.add(alert)

        # تحديث حالة الأجهزة غير المرئية
        all_devices = self.db.query(Device).all()
        found_macs = [d['mac'] for d in devices]

        for device in all_devices:
            if device.mac_address not in found_macs:
                device.is_online = False

        self.db.commit()

        return {
            'total': len(devices),
            'new': new_devices,
            'unauthorized': unauthorized_devices
        }

    def run_scan(self):
        """تشغيل فحص الشبكة"""
        if self.is_scanning:
            logger.warning("الفحص قيد التنفيذ بالفعل")
            return

        self.is_scanning = True
        scan_start = datetime.now()

        try:
            # إنشاء سجل فحص
            self.db = SessionLocal()
            scan_log = ScanLog(
                scan_type="arp",
                status="running",
                devices_found=0,
                new_devices=0,
                unauthorized_devices=0
            )
            self.db.add(scan_log)
            self.db.commit()
            self.db.refresh(scan_log)

            # تنفيذ الفحص
            devices = self.scan_network()

            # معالجة النتائج
            result = self.process_scan_results(devices)

            # تحديث سجل الفحص
            scan_log.devices_found = result['total']
            scan_log.new_devices = result['new']
            scan_log.unauthorized_devices = result['unauthorized']
            scan_log.status = "completed"
            scan_log.duration = int((datetime.now() - scan_start).total_seconds())
            self.db.commit()

            logger.info(f"اكتمل الفحص: {result['total']} جهاز, {result['new']} جديد, {result['unauthorized']} غير مصرح")

        except Exception as e:
            logger.error(f"خطأ في الفحص: {e}")
            if self.db:
                scan_log.status = "failed"
                scan_log.notes = str(e)
                self.db.commit()
        finally:
            self.is_scanning = False
            if self.db:
                self.db.close()
                self.db = None

    def start_continuous_scan(self):
        """بدء الفحص المستمر"""
        def scan_loop():
            while True:
                self.run_scan()
                time.sleep(settings.SCAN_INTERVAL)

        self.scan_thread = threading.Thread(target=scan_loop, daemon=True)
        self.scan_thread.start()
        logger.info(f"بدأ الفحص المستمر كل {settings.SCAN_INTERVAL} ثانية")

    def stop_scan(self):
        """إيقاف الفحص"""
        self.is_scanning = False
        if self.scan_thread:
            self.scan_thread.join(timeout=5)
        logger.info("تم إيقاف الفحص")


# إنشاء كائن الماسح العام
scanner = NetworkScanner()
