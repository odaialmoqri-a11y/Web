"""
مولد التقارير PDF
إنشاء تقارير أمنية بصيغة PDF
"""

import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle,
    PageBreak, Image
)
from reportlab.lib.enums import TA_CENTER, TA_RIGHT, TA_LEFT

from sqlalchemy.orm import Session

from app.db.session import SessionLocal
from app.db.models import Device, Alert, ScanLog, User
from app.services.analyzer import analyzer

logger = logging.getLogger(__name__)


class PDFReportGenerator:
    """مولد تقارير PDF"""

    def __init__(self):
        self.db: Optional[Session] = None
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()

    def _setup_custom_styles(self):
        """إعداد الأنماط المخصصة"""
        # عنوان رئيسي
        self.title_style = ParagraphStyle(
            'CustomTitle',
            parent=self.styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#0d6efd'),
            spaceAfter=30,
            alignment=TA_CENTER
        )

        # عنوان فرعي
        self.subtitle_style = ParagraphStyle(
            'Subtitle',
            parent=self.styles['Heading2'],
            fontSize=14,
            textColor=colors.HexColor('#6c757d'),
            spaceAfter=20,
            alignment=TA_CENTER
        )

        # عنوان القسم
        self.section_style = ParagraphStyle(
            'Section',
            parent=self.styles['Heading3'],
            fontSize=12,
            textColor=colors.HexColor('#343a40'),
            spaceBefore=20,
            spaceAfter=10
        )

    def generate_security_report(
        self,
        start_date: Optional[datetime] = None,
        end_date: Optional[datetime] = None,
        output_path: str = None
    ) -> bytes:
        """إنشاء تقرير أمني"""
        if not self.db:
            self.db = SessionLocal()

        if not start_date:
            start_date = datetime.now() - timedelta(days=7)
        if not end_date:
            end_date = datetime.now()

        # إنشاء اسم الملف
        if not output_path:
            output_path = f"/tmp/security_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"

        # إنشاء المستند
        doc = SimpleDocTemplate(
            output_path,
            pagesize=A4,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=72
        )

        # محتوى التقرير
        story = []

        # العنوان
        story.append(Paragraph("تقرير الأمن السيبراني", self.title_style))
        story.append(Paragraph("LAN Guardian - نظام مراقبة الشبكة", self.subtitle_style))

        # معلومات الفترة
        period_text = f"الفترة: {start_date.strftime('%Y-%m-%d')} إلى {end_date.strftime('%Y-%m-%d')}"
        story.append(Paragraph(period_text, self.styles['Normal']))
        story.append(Spacer(1, 20))

        # إحصائيات عامة
        story.append(Paragraph("ملخص الإحصائيات", self.section_style))

        total_devices = self.db.query(Device).count()
        authorized = self.db.query(Device).filter(Device.is_authorized == True).count()
        unauthorized = self.db.query(Device).filter(Device.is_authorized == False).count()
        online = self.db.query(Device).filter(Device.is_online == True).count()

        stats_data = [
            ['إجمالي الأجهزة', str(total_devices)],
            ['الأجهزة المصرح بها', str(authorized)],
            ['الأجهزة غير المصرح بها', str(unauthorized)],
            ['الأجهزة المتصلة', str(online)]
        ]

        stats_table = Table(stats_data, colWidths=[3*inch, 2*inch])
        stats_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (0, -1), colors.HexColor('#f8f9fa')),
            ('TEXTCOLOR', (0, 0), (-1, -1), colors.black),
            ('ALIGN', (0, 0), (-1, -1), 'RIGHT'),
            ('FONTNAME', (0, 0), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 8),
            ('TOPPADDING', (0, 0), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, colors.grey)
        ]))
        story.append(stats_table)
        story.append(Spacer(1, 20))

        # التنبيهات
        story.append(Paragraph("التنبيهات الأمنية", self.section_style))

        alerts = self.db.query(Alert).filter(
            Alert.created_at >= start_date,
            Alert.created_at <= end_date
        ).order_by(Alert.created_at.desc()).limit(20).all()

        if alerts:
            alert_data = [['التاريخ', 'النوع', 'الرسالة', 'الخطورة']]
            for alert in alerts:
                severity_colors = {
                    'low': 'green',
                    'medium': 'orange',
                    'high': 'red',
                    'critical': 'darkred'
                }
                color = severity_colors.get(alert.severity, 'black')
                alert_data.append([
                    alert.created_at.strftime('%Y-%m-%d %H:%M'),
                    alert.alert_type,
                    alert.message[:50] + '...' if len(alert.message) > 50 else alert.message,
                    f"<font color='{color}'>{alert.severity}</font>"
                ])

            alert_table = Table(alert_data, colWidths=[1.5*inch, 1*inch, 2.5*inch, 0.8*inch])
            alert_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0d6efd')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'RIGHT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f9fa')])
            ]))
            story.append(alert_table)
        else:
            story.append(Paragraph("لا توجد تنبيهات في هذه الفترة", self.styles['Normal']))

        story.append(Spacer(1, 20))

        # الأجهزة غير المصرح بها
        story.append(Paragraph("الأجهزة غير المصرح بها", self.section_style))

        unauthorized_devices = self.db.query(Device).filter(
            Device.is_authorized == False
        ).order_by(Device.last_seen.desc()).all()

        if unauthorized_devices:
            device_data = [['MAC', 'IP', 'المصنع', 'آخر ظهور']]
            for device in unauthorized_devices:
                device_data.append([
                    device.mac_address,
                    device.ip_address or 'N/A',
                    device.vendor or 'Unknown',
                    device.last_seen.strftime('%Y-%m-%d %H:%M') if device.last_seen else 'N/A'
                ])

            device_table = Table(device_data, colWidths=[1.8*inch, 1.2*inch, 1.5*inch, 1.5*inch])
            device_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#dc3545')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'RIGHT'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('FONTSIZE', (0, 0), (-1, -1), 9),
                ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
                ('TOPPADDING', (0, 0), (-1, -1), 6),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#fff5f5')])
            ]))
            story.append(device_table)
        else:
            story.append(Paragraph("لا توجد أجهزة غير مصرح بها", self.styles['Normal']))

        # التوقيع
        story.append(Spacer(1, 40))
        story.append(Paragraph(
            f"تم إنشاء هذا التقرير في {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}",
            self.styles['Normal']
        ))
        story.append(Paragraph("نظام LAN Guardian - مراقبة الشبكة", self.styles['Normal']))

        # بناء PDF
        doc.build(story)

        # قراءة الملف وإرجاعه كـ bytes
        with open(output_path, 'rb') as f:
            pdf_content = f.read()

        logger.info(f"تم إنشاء التقرير: {output_path}")

        if self.db:
            self.db.close()
            self.db = None

        return pdf_content

    def generate_devices_report(
        self,
        output_path: str = None
    ) -> bytes:
        """إنشاء تقرير الأجهزة"""
        if not self.db:
            self.db = SessionLocal()

        if not output_path:
            output_path = f"/tmp/devices_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf"

        doc = SimpleDocTemplate(
            output_path,
            pagesize=A4,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=72
        )

        story = []

        # العنوان
        story.append(Paragraph("تقرير الأجهزة", self.title_style))
        story.append(Paragraph("LAN Guardian - قائمة الأجهزة", self.subtitle_style))
        story.append(Spacer(1, 20))

        # الأجهزة
        devices = self.db.query(Device).order_by(Device.last_seen.desc()).all()

        device_data = [['الحالة', 'MAC', 'IP', 'اسم المضيف', 'المصنع', 'النوع']]
        for device in devices:
            status = "مصرح" if device.is_authorized else "غير مصرح"
            device_data.append([
                status,
                device.mac_address,
                device.ip_address or 'N/A',
                device.hostname or 'N/A',
                device.vendor or 'Unknown',
                device.device_type or 'N/A'
            ])

        device_table = Table(device_data, colWidths=[0.8*inch, 1.5*inch, 1*inch, 1.2*inch, 1.2*inch, 0.8*inch])
        device_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#0d6efd')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'RIGHT'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 8),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f8f9fa')])
        ]))
        story.append(device_table)

        doc.build(story)

        with open(output_path, 'rb') as f:
            pdf_content = f.read()

        if self.db:
            self.db.close()
            self.db = None

        return pdf_content


# إنشاء كائن المولد العام
pdf_generator = PDFReportGenerator()
