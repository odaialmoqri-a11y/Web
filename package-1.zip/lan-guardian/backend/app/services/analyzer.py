"""
محرك التحليل السلوكي
تحليل سلوك الأجهزة بناءً على قواعد بسيطة
"""

import logging
from datetime import datetime, timedelta
from typing import List, Dict
from collections import defaultdict

from sqlalchemy.orm import Session
from sqlalchemy import and_, or_

from app.db.session import SessionLocal
from app.db.models import Device, Alert, ScanLog

logger = logging.getLogger(__name__)


class BehaviorAnalyzer:
    """محلل السلوك"""

    def __init__(self):
        self.db: Session = None

    def analyze_device_behavior(self, device_id: int) -> List[Dict]:
        """تحليل سلوك جهاز معين"""
        if not self.db:
            self.db = SessionLocal()

        alerts = []

        device = self.db.query(Device).filter(Device.id == device_id).first()
        if not device:
            return alerts

        # التحقق من نشاط الجهاز في آخر 24 ساعة
        recent_scans = self.db.query(ScanLog).filter(
            ScanLog.created_at >= datetime.now() - timedelta(hours=24)
        ).all()

        # تحليل معدل الاتصال
        connection_rate = self._analyze_connection_rate(device)
        if connection_rate['is_suspicious']:
            alert = Alert(
                device_id=device_id,
                alert_type="suspicious",
                message=f"معدل اتصال مشبوه: {connection_rate['message']}",
                severity=connection_rate['severity']
            )
            alerts.append(alert)

        # تحليل نمط النشاط
        activity_pattern = self._analyze_activity_pattern(device)
        if activity_pattern['is_suspicious']:
            alert = Alert(
                device_id=device_id,
                alert_type="suspicious",
                message=f"نمط نشاط مشبوه: {activity_pattern['message']}",
                severity=activity_pattern['severity']
            )
            alerts.append(alert)

        # تحليل تغييرات IP
        ip_changes = self._analyze_ip_changes(device)
        if ip_changes['is_suspicious']:
            alert = Alert(
                device_id=device_id,
                alert_type="suspicious",
                message=f"تغييرات IP متعددة: {ip_changes['message']}",
                severity=ip_changes['severity']
            )
            alerts.append(alert)

        # حفظ التنبيهات
        for alert_data in alerts:
            self.db.add(alert_data)

        self.db.commit()
        return alerts

    def _analyze_connection_rate(self, device: Device) -> Dict:
        """تحليل معدل الاتصال"""
        # الحصول على سجلات الفحص الأخيرة
        if not self.db:
            self.db = SessionLocal()

        recent_logs = self.db.query(ScanLog).filter(
            ScanLog.created_at >= datetime.now() - timedelta(hours=1),
            ScanLog.device_id == device.id
        ).all()

        if len(recent_logs) < 3:
            return {'is_suspicious': False}

        # التحقق من ظهور الجهاز في أكثر من 80% من الفحوصات
        online_count = sum(1 for log in recent_logs if log.status == 'completed')
        rate = online_count / len(recent_logs)

        if rate > 0.95 and not device.is_authorized:
            return {
                'is_suspicious': True,
                'message': 'جهاز غير مصرح به يظهر نشاط عالي',
                'severity': 'high'
            }

        return {'is_suspicious': False}

    def _analyze_activity_pattern(self, device: Device) -> Dict:
        """تحليل نمط النشاط"""
        # التحقق من نشاط الجهاز في ساعات متأخرة
        current_hour = datetime.now().hour

        # نشاط غير عادي في ساعات متأخرة (2-5 صباحاً)
        if 2 <= current_hour <= 5 and device.is_online:
            # فقط للتنبيه إذا كان الجهاز غير مصرح به
            if not device.is_authorized:
                return {
                    'is_suspicious': True,
                    'message': 'نشاط في ساعات متأخرة',
                    'severity': 'medium'
                }

        return {'is_suspicious': False}

    def _analyze_ip_changes(self, device: Device) -> Dict:
        """تحليل تغييرات عنوان IP"""
        if not self.db:
            self.db = SessionLocal()

        # البحث عن تغييرات IP في السجل
        recent_devices = self.db.query(Device).filter(
            Device.mac_address == device.mac_address,
            Device.id != device.id
        ).all()

        if len(recent_devices) > 3:
            return {
                'is_suspicious': True,
                'message': f'تغيير IP متكرر ({len(recent_devices)} تغيير)',
                'severity': 'medium'
            }

        return {'is_suspicious': False}

    def run_periodic_analysis(self):
        """تشغيل التحليل الدوري"""
        if not self.db:
            self.db = SessionLocal()

        try:
            # الحصول على جميع الأجهزة النشطة
            devices = self.db.query(Device).filter(
                Device.is_online == True
            ).all()

            logger.info(f"بدء تحليل سلوكي لـ {len(devices)} جهاز")

            for device in devices:
                self.analyze_device_behavior(device.id)

            logger.info("اكتمل التحليل السلوكي")

        except Exception as e:
            logger.error(f"خطأ في التحليل السلوكي: {e}")
        finally:
            if self.db:
                self.db.close()
                self.db = None

    def generate_security_report(self, days: int = 7) -> Dict:
        """إنشاء تقرير أمني"""
        if not self.db:
            self.db = SessionLocal()

        try:
            start_date = datetime.now() - timedelta(days=days)

            # إحصائيات الأجهزة
            total_devices = self.db.query(Device).count()
            authorized = self.db.query(Device).filter(Device.is_authorized == True).count()
            unauthorized = self.db.query(Device).filter(Device.is_authorized == False).count()
            online = self.db.query(Device).filter(Device.is_online == True).count()

            # إحصائيات التنبيهات
            total_alerts = self.db.query(Alert).filter(
                Alert.created_at >= start_date
            ).count()
            unread_alerts = self.db.query(Alert).filter(
                Alert.created_at >= start_date,
                Alert.is_read == False
            ).count()

            # أهم التنبيهات
            critical_alerts = self.db.query(Alert).filter(
                Alert.created_at >= start_date,
                Alert.severity == 'critical'
            ).order_by(Alert.created_at.desc()).limit(10).all()

            # سجلات الفحص
            scans = self.db.query(ScanLog).filter(
                ScanLog.created_at >= start_date
            ).order_by(ScanLog.created_at.desc()).all()

            return {
                'period_days': days,
                'devices': {
                    'total': total_devices,
                    'authorized': authorized,
                    'unauthorized': unauthorized,
                    'online': online
                },
                'alerts': {
                    'total': total_alerts,
                    'unread': unread_alerts,
                    'critical': len(critical_alerts)
                },
                'scans': len(scans),
                'critical_alerts': [
                    {
                        'id': a.id,
                        'message': a.message,
                        'severity': a.severity,
                        'created_at': a.created_at.isoformat()
                    } for a in critical_alerts
                ]
            }

        except Exception as e:
            logger.error(f"خطأ في إنشاء التقرير: {e}")
            return {}
        finally:
            if self.db:
                self.db.close()
                self.db = None


# إنشاء كائن المحلل العام
analyzer = BehaviorAnalyzer()
