"""
نماذج قاعدة البيانات
تعريف جداول MySQL للكيانات الرئيسية
"""

from sqlalchemy import Column, Integer, String, Boolean, DateTime, ForeignKey, Text
from sqlalchemy.orm import relationship
from sqlalchemy.sql import func

from app.db.session import Base


class User(Base):
    """جدول المستخدمين"""
    __tablename__ = "users"

    id = Column(Integer, primary_key=True, index=True)
    username = Column(String(50), unique=True, index=True, nullable=False)
    email = Column(String(100), unique=True, index=True, nullable=True)
    password_hash = Column(String(255), nullable=False)
    role = Column(String(20), default="viewer")  # admin or viewer
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), onupdate=func.now())

    # العلاقات
    alerts = relationship("Alert", back_populates="user")
    scan_logs = relationship("ScanLog", back_populates="user")


class Device(Base):
    """جدول الأجهزة"""
    __tablename__ = "devices"

    id = Column(Integer, primary_key=True, index=True)
    mac_address = Column(String(17), unique=True, index=True, nullable=False)
    ip_address = Column(String(15), index=True, nullable=True)
    hostname = Column(String(255), nullable=True)
    vendor = Column(String(100    device_type =), nullable=True)
 Column(String(50), nullable=True)  # router, pc, mobile, iot
    is_authorized = Column(Boolean, default=False)
    is_online = Column(Boolean, default=True)
    first_seen = Column(DateTime(timezone=True), server_default=func.now())
    last_seen = Column(DateTime(timezone=True), server_default=func.now())
    authorized_at = Column(DateTime(timezone=True), nullable=True)
    notes = Column(Text, nullable=True)

    # العلاقات
    alerts = relationship("Alert", back_populates="device")
    scan_logs = relationship("ScanLog", back_populates="device")


class Alert(Base):
    """جدول التنبيهات"""
    __tablename__ = "alerts"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    alert_type = Column(String(50), nullable=False)  # unauthorized, suspicious, offline
    message = Column(Text, nullable=False)
    severity = Column(String(20), default="medium")  # low, medium, high, critical
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # العلاقات
    device = relationship("Device", back_populates="alerts")
    user = relationship("User", back_populates="alerts")


class ScanLog(Base):
    """جدول سجلات الفحص"""
    __tablename__ = "scan_logs"

    id = Column(Integer, primary_key=True, index=True)
    device_id = Column(Integer, ForeignKey("devices.id"), nullable=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    scan_type = Column(String(50), default="arp")  # arp, ping, full
    devices_found = Column(Integer, default=0)
    new_devices = Column(Integer, default=0)
    unauthorized_devices = Column(Integer, default=0)
    status = Column(String(20), default="completed")  # running, completed, failed
    duration = Column(Integer, nullable=True)  # seconds
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())

    # العلاقات
    device = relationship("Device", back_populates="scan_logs")
    user = relationship("User", back_populates="scan_logs")


class AuditLog(Base):
    """جدول سجلات التدقيق"""
    __tablename__ = "audit_logs"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=True)
    action = Column(String(100), nullable=False)
    entity_type = Column(String(50), nullable=True)  # device, user, alert
    entity_id = Column(Integer, nullable=True)
    details = Column(Text, nullable=True)
    ip_address = Column(String(45), nullable=True)
    created_at = Column(DateTime(timezone=True), server_default=func.now())
