import React, { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import {
  FaNetworkWired,
  FaDesktop,
  FaBell,
  FaFileAlt,
  FaBars,
  FaSignOutAlt,
  FaUser,
} from 'react-icons/fa';

function Layout({ children }) {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const { user, logout } = useAuth();
  const location = useLocation();

  const navItems = [
    { path: '/', label: 'لوحة التحكم', icon: <FaNetworkWired /> },
    { path: '/devices', label: 'الأجهزة', icon: <FaDesktop /> },
    { path: '/alerts', label: 'التنبيهات', icon: <FaBell /> },
    { path: '/reports', label: 'التقارير', icon: <FaFileAlt /> },
  ];

  return (
    <div className="d-flex">
      {/* الشريط الجانبي */}
      <div className={`sidebar ${sidebarOpen ? 'show' : ''}`}>
        <div className="sidebar-brand">
          <FaNetworkWired className="ms-2" />
          LAN Guardian
        </div>
        <nav className="nav flex-column mt-3">
          {navItems.map((item) => (
            <Link
              key={item.path}
              to={item.path}
              className={`nav-link d-flex align-items-center ${
                location.pathname === item.path ? 'active' : ''
              }`}
              onClick={() => setSidebarOpen(false)}
            >
              <span className="ms-2">{item.icon}</span>
              {item.label}
            </Link>
          ))}
        </nav>
      </div>

      {/* المحتوى الرئيسي */}
      <div className="flex-grow-1">
        {/* شريط التنقل العلوي */}
        <nav className="navbar navbar-expand-lg sticky-top">
          <div className="container-fluid">
            <button
              className="btn btn-link text-dark"
              onClick={() => setSidebarOpen(!sidebarOpen)}
            >
              <FaBars size={24} />
            </button>

            <div className="d-flex align-items-center ms-auto">
              <div className="dropdown">
                <button
                  className="btn btn-link text-dark dropdown-toggle d-flex align-items-center"
                  type="button"
                  data-bs-toggle="dropdown"
                >
                  <FaUser className="ms-2" />
                  {user?.username}
                </button>
                <ul className="dropdown-menu dropdown-menu-end">
                  <li>
                    <span className="dropdown-item-text">
                      الدور: {user?.role === 'admin' ? 'مدير' : 'مشاهد'}
                    </span>
                  </li>
                  <li><hr className="dropdown-divider" /></li>
                  <li>
                    <button className="dropdown-item text-danger" onClick={logout}>
                      <FaSignOutAlt className="ms-2" />
                      تسجيل الخروج
                    </button>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </nav>

        {/* محتوى الصفحة */}
        <main className="main-content">
          {children}
        </main>
      </div>
    </div>
  );
}

export default Layout;
