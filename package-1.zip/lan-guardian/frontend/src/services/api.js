import axios from 'axios';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api/v1';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// إضافة token لكل طلب
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// معالجة أخطاء الاستجابة
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// واجهة API للأجهزة
export const devicesAPI = {
  getAll: (params) => api.get('/devices', { params }),
  getById: (id) => api.get(`/devices/${id}`),
  create: (data) => api.post('/devices', data),
  update: (id, data) => api.put(`/devices/${id}`, data),
  authorize: (id) => api.put(`/devices/${id}/authorize`),
  delete: (id) => api.delete(`/devices/${id}`),
  getStats: () => api.get('/devices/stats'),
};

// واجهة API للوحة التحكم
export const dashboardAPI = {
  getStats: () => api.get('/dashboard/stats'),
  getActivity: (hours = 24) => api.get(`/dashboard/activity?hours=${hours}`),
  getRecentAlerts: (limit = 10) => api.get(`/dashboard/recent-alerts?limit=${limit}`),
  getScanHistory: (limit = 20) => api.get(`/dashboard/scan-history?limit=${limit}`),
  triggerScan: () => api.post('/dashboard/scan'),
  getScanStatus: () => api.get('/dashboard/scan-status'),
};

// واجهة API للتنبيهات
export const alertsAPI = {
  getAll: (params) => api.get('/devices/alerts', { params }),
  markAsRead: (id) => api.put(`/devices/alerts/${id}/read`),
  markAllAsRead: () => api.put('/devices/alerts/read-all'),
};

// واجهة API للتقارير
export const reportsAPI = {
  getSecurityReport: (params) => api.get('/reports/security', { params, responseType: 'blob' }),
  getDevicesReport: () => api.get('/reports/devices', { responseType: 'blob' }),
  getAlertsReport: (params) => api.get('/reports/alerts', { params, responseType: 'blob' }),
  getSummary: (days = 7) => api.get(`/reports/summary?days=${days}`),
};

// واجهة API للمصادقة
export const authAPI = {
  login: (credentials) => api.post('/auth/login', credentials),
  getMe: () => api.get('/auth/me'),
  register: (data) => api.post('/auth/register', data),
};

export default api;
