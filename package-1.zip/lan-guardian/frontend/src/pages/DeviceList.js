import React, { useState, useEffect } from 'react';
import { Card, Table, Button, Spinner, Badge, Form, InputGroup, Row, Col } from 'react-bootstrap';
import {
  FaSearch,
  FaCheck,
  FaTrash,
  FaSync,
  FaFilter,
} from 'react-icons/fa';
import { devicesAPI } from '../services/api';
import { toast } from 'react-toastify';

function DeviceList() {
  const [devices, setDevices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState('all'); // all, authorized, unauthorized, online, offline
  const [stats, setStats] = useState(null);

  useEffect(() => {
    fetchDevices();
  }, [search, filter]);

  const fetchDevices = async () => {
    setLoading(true);
    try {
      const params = {};
      if (search) params.search = search;
      if (filter === 'authorized') params.authorized = true;
      if (filter === 'unauthorized') params.authorized = false;
      if (filter === 'online') params.online = true;
      if (filter === 'offline') params.online = false;

      const [devicesRes, statsRes] = await Promise.all([
        devicesAPI.getAll(params),
        devicesAPI.getStats(),
      ]);

      setDevices(devicesRes.data);
      setStats(statsRes.data);
    } catch (error) {
      console.error('Error fetching devices:', error);
      toast.error('فشل في تحميل الأجهزة');
    } finally {
      setLoading(false);
    }
  };

  const handleAuthorize = async (deviceId) => {
    try {
      await devicesAPI.authorize(deviceId);
      toast.success('تم الموافقة على الجهاز');
      fetchDevices();
    } catch (error) {
      toast.error('فشل في الموافقة على الجهاز');
    }
  };

  const handleDelete = async (deviceId) => {
    if (!window.confirm('هل أنت متأكد من حذف هذا الجهاز؟')) return;

    try {
      await devicesAPI.delete(deviceId);
      toast.success('تم حذف الجهاز');
      fetchDevices();
    } catch (error) {
      toast.error('فشل في حذف الجهاز');
    }
  };

  const getStatusBadge = (device) => {
    if (!device.is_online) {
      return <Badge bg="secondary">غير متصل</Badge>;
    }
    if (!device.is_authorized) {
      return <Badge bg="danger">غير مصرح</Badge>;
    }
    return <Badge bg="success">مصرح</Badge>;
  };

  if (loading && devices.length === 0) {
    return (
      <div className="loading-spinner">
        <Spinner animation="border" variant="primary" />
      </div>
    );
  }

  return (
    <div className="fade-in">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>الأجهزة</h2>
        <Button variant="outline-primary" onClick={fetchDevices}>
          <FaSync className="me-2" />
          تحديث
        </Button>
      </div>

      {/* الإحصائيات */}
      <Row className="mb-4">
        <Col md={3}>
          <Card className="stat-card mb-3">
            <Card.Body>
              <div className="stat-value">{stats?.total_devices || 0}</div>
              <div className="stat-label">إجمالي الأجهزة</div>
            </Card.Body>
          </Card>
        </Col>
        <Col md={3}>
          <Card className="stat-card success mb-3">
            <Card.Body>
              <div className="stat-value">{stats?.online_devices || 0}</div>
              <div className="stat-label">متصل</div>
            </Card.Body>
          </Card>
        </Col>
        <Col md={3}>
          <Card className="stat-card danger mb-3">
            <Card.Body>
              <div className="stat-value">{stats?.unauthorized_devices || 0}</div>
              <div className="stat-label">غير مصرح</div>
            </Card.Body>
          </Card>
        </Col>
        <Col md={3}>
          <Card className="stat-card warning mb-3">
            <Card.Body>
              <div className="stat-value">{stats?.new_today || 0}</div>
              <div className="stat-label">جديد اليوم</div>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* الفلاتر والبحث */}
      <Card className="mb-4">
        <Card.Body>
          <Row>
            <Col md={6}>
              <InputGroup>
                <InputGroup.Text>
                  <FaSearch />
                </InputGroup.Text>
                <Form.Control
                  placeholder="بحث بالـ MAC أو IP أو الاسم..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </InputGroup>
            </Col>
            <Col md={4}>
              <InputGroup>
                <InputGroup.Text>
                  <FaFilter />
                </InputGroup.Text>
                <Form.Select
                  value={filter}
                  onChange={(e) => setFilter(e.target.value)}
                >
                  <option value="all">الكل</option>
                  <option value="authorized">مصرح</option>
                  <option value="unauthorized">غير مصرح</option>
                  <option value="online">متصل</option>
                  <option value="offline">غير متصل</option>
                </Form.Select>
              </InputGroup>
            </Col>
            <Col md={2}>
              <Button variant="secondary" onClick={() => setSearch('')}>
                مسح
              </Button>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      {/* جدول الأجهزة */}
      <Card>
        <Card.Body className="p-0">
          <Table responsive hover className="mb-0">
            <thead>
              <tr>
                <th>الحالة</th>
                <th>عنوان MAC</th>
                <th>عنوان IP</th>
                <th>اسم المضيف</th>
                <th>المصنع</th>
                <th>آخر ظهور</th>
                <th>الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {devices.length === 0 ? (
                <tr>
                  <td colSpan="7" className="text-center py-4 text-muted">
                    لا توجد أجهزة
                  </td>
                </tr>
              ) : (
                devices.map((device) => (
                  <tr
                    key={device.id}
                    className={`device-row ${
                      !device.is_authorized && device.is_online ? 'unauthorized' : ''
                    }`}
                  >
                    <td>{getStatusBadge(device)}</td>
                    <td className="font-monospace">{device.mac_address}</td>
                    <td>{device.ip_address || '-'}</td>
                    <td>{device.hostname || '-'}</td>
                    <td>{device.vendor || 'غير معروف'}</td>
                    <td>
                      {device.last_seen
                        ? new Date(device.last_seen).toLocaleString('ar-SA')
                        : '-'}
                    </td>
                    <td>
                      {!device.is_authorized && (
                        <Button
                          variant="success"
                          size="sm"
                          className="me-2 btn-action"
                          onClick={() => handleAuthorize(device.id)}
                        >
                          <FaCheck className="me-1" />
                          موافقة
                        </Button>
                      )}
                      <Button
                        variant="danger"
                        size="sm"
                        className="btn-action"
                        onClick={() => handleDelete(device.id)}
                      >
                        <FaTrash className="me-1" />
                        حذف
                      </Button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </Table>
        </Card.Body>
      </Card>
    </div>
  );
}

export default DeviceList;
