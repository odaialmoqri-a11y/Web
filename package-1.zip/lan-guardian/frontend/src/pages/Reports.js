import React, { useState, useEffect } from 'react';
import { Card, Row, Col, Button, Spinner, Form } from 'react-bootstrap';
import { FaFilePdf, FaFileAlt, FaDownload } from 'react-icons/fa';
import { reportsAPI } from '../services/api';
import { toast } from 'react-toastify';

function Reports() {
  const [summary, setSummary] = useState(null);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [dateRange, setDateRange] = useState({
    startDate: '',
    endDate: '',
  });

  useEffect(() => {
    fetchSummary();
  }, []);

  const fetchSummary = async () => {
    setLoading(true);
    try {
      const response = await reportsAPI.getSummary(7);
      setSummary(response.data);
    } catch (error) {
      console.error('Error fetching summary:', error);
    } finally {
      setLoading(false);
    }
  };

  const downloadReport = async (reportType) => {
    setGenerating(true);
    try {
      let response;
      const filename = `${reportType}_report_${new Date().toISOString().split('T')[0]}.pdf`;

      switch (reportType) {
        case 'security':
          response = await reportsAPI.getSecurityReport({
            start_date: dateRange.startDate,
            end_date: dateRange.endDate,
          });
          break;
        case 'devices':
          response = await reportsAPI.getDevicesReport();
          break;
        case 'alerts':
          response = await reportsAPI.getAlertsReport({
            start_date: dateRange.startDate,
            end_date: dateRange.endDate,
          });
          break;
        default:
          return;
      }

      // إنشاء رابط التحميل
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', filename);
      document.body.appendChild(link);
      link.click();
      link.remove();
      window.URL.revokeObjectURL(url);

      toast.success('تم تحميل التقرير بنجاح');
    } catch (error) {
      console.error('Error downloading report:', error);
      toast.error('فشل في تحميل التقرير');
    } finally {
      setGenerating(false);
    }
  };

  if (loading) {
    return (
      <div className="loading-spinner">
        <Spinner animation="border" variant="primary" />
      </div>
    );
  }

  return (
    <div className="fade-in">
      <h2 className="mb-4">التقارير</h2>

      {/* ملخص التقارير */}
      <Card className="mb-4">
        <Card.Header>ملخص الأسبوع</Card.Header>
        <Card.Body>
          <Row>
            <Col md={4}>
              <h5>الأجهزة</h5>
              <p className="mb-1">
                <strong>إجمالي:</strong> {summary?.devices?.total || 0}
              </p>
              <p className="mb-1">
                <strong>مصرح:</strong> {summary?.devices?.authorized || 0}
              </p>
              <p>
                <strong>غير مصرح:</strong> {summary?.devices?.unauthorized || 0}
              </p>
            </Col>
            <Col md={4}>
              <h5>التنبيهات</h5>
              <p className="mb-1">
                <strong>الإجمالي:</strong> {summary?.alerts?.total || 0}
              </p>
              <p className="mb-1">
                <strong>حرجة:</strong> {summary?.alerts?.critical || 0}
              </p>
              <p>
                <strong>عالية:</strong> {summary?.alerts?.high || 0}
              </p>
            </Col>
            <Col md={4}>
              <h5>عمليات الفحص</h5>
              <p>
                <strong>عدد الفحوصات:</strong> {summary?.scans || 0}
              </p>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      {/* نطاق التاريخ */}
      <Card className="mb-4">
        <Card.Header>نطاق التاريخ (اختياري)</Card.Header>
        <Card.Body>
          <Row>
            <Col md={5}>
              <Form.Group>
                <Form.Label>من تاريخ</Form.Label>
                <Form.Control
                  type="date"
                  value={dateRange.startDate}
                  onChange={(e) =>
                    setDateRange({ ...dateRange, startDate: e.target.value })
                  }
                />
              </Form.Group>
            </Col>
            <Col md={5}>
              <Form.Group>
                <Form.Label>إلى تاريخ</Form.Label>
                <Form.Control
                  type="date"
                  value={dateRange.endDate}
                  onChange={(e) =>
                    setDateRange({ ...dateRange, endDate: e.target.value })
                  }
                />
              </Form.Group>
            </Col>
            <Col md={2} className="d-flex align-items-end">
              <Button
                variant="outline-secondary"
                className="w-100"
                onClick={() => setDateRange({ startDate: '', endDate: '' })}
              >
                مسح
              </Button>
            </Col>
          </Row>
        </Card.Body>
      </Card>

      {/* أنواع التقارير */}
      <Row>
        <Col md={4}>
          <Card className="h-100">
            <Card.Body className="d-flex flex-column align-items-center">
              <FaFilePdf size={50} className="text-danger mb-3" />
              <h5>تقرير أمني</h5>
              <p className="text-muted text-center small">
                يشمل إحصائيات الأجهزة والتنبيهات والأجهزة غير المصرح بها
              </p>
              <Button
                variant="danger"
                className="mt-auto"
                onClick={() => downloadReport('security')}
                disabled={generating}
              >
                <FaDownload className="me-2" />
                {generating ? 'جاري التحميل...' : 'تحميل PDF'}
              </Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4}>
          <Card className="h-100">
            <Card.Body className="d-flex flex-column align-items-center">
              <FaFileAlt size={50} className="text-primary mb-3" />
              <h5>تقرير الأجهزة</h5>
              <p className="text-muted text-center small">
                قائمة بجميع الأجهزة المكتشفة في الشبكة
              </p>
              <Button
                variant="primary"
                className="mt-auto"
                onClick={() => downloadReport('devices')}
                disabled={generating}
              >
                <FaDownload className="me-2" />
                {generating ? 'جاري التحميل...' : 'تحميل PDF'}
              </Button>
            </Card.Body>
          </Card>
        </Col>

        <Col md={4}>
          <Card className="h-100">
            <Card.Body className="d-flex flex-column align-items-center">
              <FaFileAlt size={50} className="text-warning mb-3" />
              <h5>تقرير التنبيهات</h5>
              <p className="text-muted text-center small">
                سجل جميع التنبيهات والتحذيرات الأمنية
              </p>
              <Button
                variant="warning"
                className="mt-auto"
                onClick={() => downloadReport('alerts')}
                disabled={generating}
              >
                <FaDownload className="me-2" />
                {generating ? 'جاري التحميل...' : 'تحميل PDF'}
              </Button>
            </Card.Body>
          </Card>
        </Col>
      </Row>
    </div>
  );
}

export default Reports;
