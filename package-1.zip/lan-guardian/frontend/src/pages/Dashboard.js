import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Card, Row, Col, Button, Spinner, Badge } from 'react-bootstrap';
import {
  FaDesktop,
  FaWifi,
  FaExclamationTriangle,
  FaPlus,
  FaBell,
  FaSync,
} from 'react-icons/fa';
import { dashboardAPI } from '../services/api';
import { Line } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend,
} from 'chart.js';

ChartJS.register(
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  Title,
  Tooltip,
  Legend
);

function Dashboard() {
  const [stats, setStats] = useState(null);
  const [activity, setActivity] = useState([]);
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [scanning, setScanning] = useState(false);

  useEffect(() => {
    fetchData();
    const interval = setInterval(fetchData, 30000);
    return () => clearInterval(interval);
  }, []);

  const fetchData = async () => {
    try {
      const [statsRes, activityRes, alertsRes] = await Promise.all([
        dashboardAPI.getStats(),
        dashboardAPI.getActivity(24),
        dashboardAPI.getRecentAlerts(5),
      ]);
      setStats(statsRes.data);
      setActivity(activityRes.data);
      setAlerts(alertsRes.data);
    } catch (error) {
Error fetching dashboard data:', error);
      console.error('    } finally {
      setLoading(false);
    }
  };

  const handleScan = async () => {
    setScanning(true);
    try {
      await dashboardAPI.triggerScan();
      setTimeout(fetchData, 5000);
    } catch (error) {
      console.error('Error triggering scan:', error);
    } finally {
      setScanning(false);
    }
  };

  if (loading) {
    return (
      <div className="loading-spinner">
        <Spinner animation="border" variant="primary" />
      </div>
    );
  }

  const chartData = {
    labels: activity.slice(-12).map((a) =>
      new Date(a.timestamp).toLocaleTimeString('ar-SA', { hour: '2-digit', minute: '2-digit' })
    ),
    datasets: [
      {
        label: 'الأجهزة المتصلة',
        data: activity.slice(-12).map((a) => a.devices_online),
        borderColor: '#0d6efd',
        backgroundColor: 'rgba(13, 110, 253, 0.1)',
        tension: 0.4,
      },
      {
        label: 'أجهزة جديدة',
        data: activity.slice(-12).map((a) => a.new_devices),
        borderColor: '#198754',
        backgroundColor: 'rgba(25, 135, 84, 0.1)',
        tension: 0.4,
      },
    ],
  };

  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: {
      legend: {
        position: 'top',
        labels: {
          font: {
            family: 'Cairo',
          },
        },
      },
    },
    scales: {
      y: {
        beginAtZero: true,
        ticks: {
          font: {
            family: 'Cairo',
          },
        },
      },
      x: {
        ticks: {
          font: {
            family: 'Cairo',
          },
        },
      },
    },
  };

  return (
    <div className="fade-in">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>لوحة التحكم</h2>
        <Button
          variant="primary"
          onClick={handleScan}
          disabled={scanning}
        >
          <FaSync className={`me-2 ${scanning ? 'pulse' : ''}`} />
          {scanning ? 'جاري الفحص...' : 'تشغيل فحص'}
        </Button>
      </div>

      {/* بطاقات الإحصائيات */}
      <Row className="mb-4">
        <Col md={3}>
          <Card className="stat-card mb-3">
            <Card.Body>
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <div className="stat-value">{stats?.total_devices || 0}</div>
                  <div className="stat-label">إجمالي الأجهزة</div>
                </div>
                <FaDesktop className="stat-icon text-primary" />
              </div>
            </Card.Body>
          </Card>
        </Col>

        <Col md={3}>
          <Card className="stat-card success mb-3">
            <Card.Body>
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <div className="stat-value">{stats?.online_devices || 0}</div>
                  <div className="stat-label">الأجهزة المتصلة</div>
                </div>
                <FaWifi className="stat-icon text-success" />
              </div>
            </Card.Body>
          </Card>
        </Col>

        <Col md={3}>
          <Card className="stat-card danger mb-3">
            <Card.Body>
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <div className="stat-value">{stats?.unauthorized_devices || 0}</div>
                  <div className="stat-label">غير مصرح بها</div>
                </div>
                <FaExclamationTriangle className="stat-icon text-danger" />
              </div>
            </Card.Body>
          </Card>
        </Col>

        <Col md={3}>
          <Card className="stat-card warning mb-3">
            <Card.Body>
              <div className="d-flex justify-content-between align-items-center">
                <div>
                  <div className="stat-value">{stats?.new_today || 0}</div>
                  <div className="stat-label">جديد اليوم</div>
                </div>
                <FaPlus className="stat-icon text-warning" />
              </div>
            </Card.Body>
          </Card>
        </Col>
      </Row>

      <Row>
        {/* الرسم البياني */}
        <Col lg={8}>
          <Card className="mb-4">
            <Card.Header>نشاط الشبكة (آخر 24 ساعة)</Card.Header>
            <Card.Body>
              <div style={{ height: '300px' }}>
                <Line data={chartData} options={chartOptions} />
              </div>
            </Card.Body>
          </Card>
        </Col>

        {/* أحدث التنبيهات */}
        <Col lg={4}>
          <Card className="mb-4">
            <Card.Header className="d-flex justify-content-between align-items-center">
              <span>أحدث التنبيهات</span>
              <Link to="/alerts">
                <Badge bg="primary">عرض الكل</Badge>
              </Link>
            </Card.Header>
            <Card.Body style={{ maxHeight: '350px', overflowY: 'auto' }}>
              {alerts.length === 0 ? (
                <div className="text-center text-muted py-4">
                  <FaBell className="mb-2" size={30} />
                  <p className="mb-0">لا توجد تنبيهات</p>
                </div>
              ) : (
                alerts.map((alert) => (
                  <div
                    key={alert.id}
                    className={`alert-badge d-flex justify-content-between align-items-center mb-2 p-2 ${
                      alert.severity === 'critical'
                        ? 'alert-critical'
                        : alert.severity === 'high'
                        ? 'alert-high'
                        : alert.severity === 'medium'
                        ? 'alert-medium'
                        : 'alert-low'
                    }`}
                  >
                    <span className="small">{alert.message}</span>
                    {!alert.is_read && <Badge bg="danger">جديد</Badge>}
                  </div>
                ))
              )}
            </Card.Body>
          </Card>
        </Col>
      </Row>

      {/* معلومات آخر فحص */}
      <Card>
        <Card.Header>معلومات الفحص</Card.Header>
        <Card.Body>
          <Row>
            <Col md={4}>
              <p className="mb-1">
                <strong>آخر فحص:</strong>{' '}
                {stats?.last_scan
                  ? new Date(stats.last_scan).toLocaleString('ar-SA')
                  : 'لم يتم الفحص بعد'}
              </p>
            </Col>
            <Col md={4}>
              <p className="mb-1">
                <strong>إجمالي التنبيهات:</strong> {stats?.total_alerts || 0}
              </p>
            </Col>
            <Col md={4}>
              <p className="mb-1">
                <strong>تنبيهات غير مقروءة:</strong> {stats?.unread_alerts || 0}
              </p>
            </Col>
          </Row>
        </Card.Body>
      </Card>
    </div>
  );
}

export default Dashboard;
