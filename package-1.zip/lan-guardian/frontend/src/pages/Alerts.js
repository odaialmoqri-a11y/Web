import React, { useState, useEffect } from 'react';
import { Card, Table, Button, Badge, Spinner } from 'react-bootstrap';
import { FaBell, FaCheck, FaCheckDouble, FaTrash } from 'react-icons/fa';
import { alertsAPI } from '../services/api';
import { toast } from 'react-toastify';

function Alerts() {
  const [alerts, setAlerts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState('all'); // all, unread

  useEffect(() => {
    fetchAlerts();
  }, [filter]);

  const fetchAlerts = async () => {
    setLoading(true);
    try {
      const params = {};
      if (filter === 'unread') params.unread_only = true;

      const response = await alertsAPI.getAll(params);
      setAlerts(response.data);
    } catch (error) {
      console.error('Error fetching alerts:', error);
      toast.error('فشل في تحميل التنبيهات');
    } finally {
      setLoading(false);
    }
  };

  const handleMarkAsRead = async (alertId) => {
    try {
      await alertsAPI.markAsRead(alertId);
      toast.success('تم وضع علامة مقروء');
      fetchAlerts();
    } catch (error) {
      toast.error('فشل في تحديث التنبيه');
    }
  };

  const handleMarkAllAsRead = async () => {
    try {
      await alertsAPI.markAllAsRead();
      toast.success('تم وضع علامة مقروء على الكل');
      fetchAlerts();
    } catch (error) {
      toast.error('فشل في تحديث التنبيهات');
    }
  };

  const getSeverityBadge = (severity) => {
    const variants = {
      critical: 'danger',
      high: 'warning',
      medium: 'info',
      low: 'success',
    };
    return <Badge bg={variants[severity] || 'secondary'}>{severity}</Badge>;
  };

  const getTypeLabel = (type) => {
    const labels = {
      unauthorized: 'غير مصرح',
      suspicious: 'مشبوه',
      authorized: 'مو عليه',
      offlineافق: 'غير متصل',
    };
    return labels[type] || type;
  };

  if (loading && alerts.length === 0) {
    return (
      <div className="loading-spinner">
        <Spinner animation="border" variant="primary" />
      </div>
    );
  }

  return (
    <div className="fade-in">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <h2>التنبيهات</h2>
        <div>
          <Button
            variant="outline-primary"
            className="me-2"
            onClick={() => setFilter(filter === 'all' ? 'unread' : 'all')}
          >
            {filter === 'all' ? 'إظهار غير المقروء' : 'إظهار الكل'}
          </Button>
          <Button variant="outline-success" onClick={handleMarkAllAsRead}>
            <FaCheckDouble className="me-2" />
            وضع علامة مقروء على الكل
          </Button>
        </div>
      </div>

      <Card>
        <Card.Body className="p-0">
          <Table responsive hover className="mb-0">
            <thead>
              <tr>
                <th>الحالة</th>
                <th>النوع</th>
                <th>الرسالة</th>
                <th>الخطورة</th>
                <th>التاريخ</th>
                <th>الإجراءات</th>
              </tr>
            </thead>
            <tbody>
              {alerts.length === 0 ? (
                <tr>
                  <td colSpan="6" className="text-center py-4 text-muted">
                    <FaBell className="mb-2" size={30} />
                    <p className="mb-0">لا توجد تنبيهات</p>
                  </td>
                </tr>
              ) : (
                alerts.map((alert) => (
                  <tr
                    key={alert.id}
                    className={!alert.is_read ? 'table-warning' : ''}
                  >
                    <td>
                      {alert.is_read ? (
                        <Badge bg="secondary">مقروء</Badge>
                      ) : (
                        <Badge bg="primary">جديد</Badge>
                      )}
                    </td>
                    <td>{getTypeLabel(alert.alert_type)}</td>
                    <td style={{ maxWidth: '300px' }}>{alert.message}</td>
                    <td>{getSeverityBadge(alert.severity)}</td>
                    <td>
                      {new Date(alert.created_at).toLocaleString('ar-SA')}
                    </td>
                    <td>
                      {!alert.is_read && (
                        <Button
                          variant="outline-success"
                          size="sm"
                          onClick={() => handleMarkAsRead(alert.id)}
                        >
                          <FaCheck className="me-1" />
                          قراءة
                        </Button>
                      )}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </Table>
        </Card.Body>
      </Card>
    </div>
  );
}

export default Alerts;
